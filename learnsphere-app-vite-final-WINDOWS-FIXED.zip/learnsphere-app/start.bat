@echo off
cd /d "%~dp0"
echo.
echo ==========================================
echo        LearnSphere - Vite + Node.js
echo ==========================================
echo.
echo First time only: npm install
echo Then: npm run dev
echo.
npm run dev
pause
