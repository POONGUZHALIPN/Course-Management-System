# LearnSphere — Full-Stack Student/Admin Learning Platform

Vite + Node.js full-stack app. The frontend uses Vite for development, while the backend remains Node.js.
The frontend remains your real HTML/CSS/JS; `server.js` provides the clean-URL
routing layer and the JSON-backed API. No React is required. Vite is used for the frontend development server. `node_modules` is intentionally not included in the ZIP.

## Run it

First time only:

```bash
npm install
```

Then:

```bash
npm run dev
```

This starts the Node.js backend on port 3000 and the Vite frontend on port 5173.
`node_modules` is not included in the ZIP; npm creates it locally from `package.json`.
On Windows, `dev-server.js` launches Vite through the shell because `vite.cmd` is a Windows command script.

Once you see `LearnSphere server running`, open:
```
http://localhost:3000
```

## Routing

The server maps clean URLs to the matching static page in `public/`:

| URL | Serves |
|---|---|
| `/` | `public/index.html` |
| `/login` | `public/pages/login.html` |
| `/register` | `public/pages/register.html` |
| `/admin-login` | `public/pages/admin-login.html` |
| `/admin-register` | `public/pages/admin-register.html` |
| `/forgot-password` | `public/pages/forgot-password.html` |
| `/account-settings` | `public/pages/account-settings.html` |
| `/student-dashboard` | `public/pages/student-dashboard.html` |
| `/admin-dashboard` | `public/pages/admin-dashboard.html` |
| `/course-player` | `public/pages/course-player.html` |

The `...html` version of each path (e.g. `/login.html`) also works, as
a safety net — but every link, script redirect, and logout button in
this project uses the clean path, so you'll never actually see `.html`
in the address bar during normal use.

This routing lives entirely in `server.js` (see `PAGE_ROUTES`) — no
front-end framework, no router library, nothing to build. Each page also
accepts its clean URL, `.html` URL, and `/pages/...` URL so legacy links do
not produce a 404.

## Demo accounts

**Student**
| Email | Password |
|---|---|
| aarav@example.com | password123 |
| sneha@example.com | password123 |
| rahul@example.com | password123 |
| priya@example.com | password123 |
| meera@example.com | password123 |

**Admin**
| Email | Password |
|---|---|
| admin@learnsphere.com | admin123 |

You can also register a brand-new student from the Register page, or a
brand-new **admin** from the Admin Login page → "Register here" (see
invite code below). Both are saved to `data/db.json` immediately.

**Admin invite code:** `LEARNSPHERE2026`
Change `ADMIN_INVITE_CODE` at the top of `server.js` to set your own.

## The actual course-taking experience

Each of the 6 courses has real content:

- **Learning path** — 3 modules per course (reading + a video lesson).
  Click through them in order, then "Mark Complete & Continue."
- **Final quiz** — unlocks once all modules are complete. 5 multiple-choice
  questions, need 60% to pass.
- **Certificate** — passing the quiz marks the course "Completed" and
  shows a certificate on the student dashboard.
- Progress is weighted: modules make up 80% of the course, the quiz is
  worth the final 20%.

Course content lives in `data/courseContent.json` — add a course by
adding a new top-level key there whose name matches an entry in
`courseCatalog` inside `data/db.json`.

## Password reset (one-time code, not a link)

1. Enter your email on **Forgot Password** → a 6-digit code is generated.
2. No email server is configured in this demo, so the code is shown
   directly on the page (clearly marked as a demo stand-in).
3. Enter the code plus a new password, right there on the same page.

Codes expire after 15 minutes. To change your password while already
**logged in**, use **Account Settings** instead — session-based, no code.

## API summary

- `POST /api/register` — student sign-up
- `POST /api/login`, `POST /api/admin/login` — sign in, sets a session cookie
- `POST /api/admin/register` — admin sign-up, requires the invite code
- `GET /api/me` — who's currently logged in
- `POST /api/logout` — clears the session
- `GET /api/student/dashboard` — the logged-in student's courses, progress, stats
- `GET /api/courses/:course/content` — that course's modules + quiz + progress
- `POST /api/student/courses/:course/modules/:moduleId/complete` — marks a module done
- `POST /api/student/courses/:course/quiz/submit` — grades the quiz
- `GET /api/admin/overview` — totals, course-wise stats, registered-students table
- `POST /api/forgot-password` — generates a reset code
- `POST /api/reset-password` — verifies the code and sets a new password
- `POST /api/change-password` — session-based password change

## Project structure

```
learnsphere-app/
  server.js                 Pure Node.js HTTP server + API routes + page routing
  package.json
  start.bat / start.sh      double-click to run, no terminal typing needed
  data/
    db.json                 accounts, enrollments, course catalog
    courseContent.json      modules + quiz questions per course
  public/
    index.html
    css/theme.css
    js/                     api.js + one script per page
    pages/                  the other 9 pages (served at clean URLs, see above)
```

## Notes for going further

- The "database" is two JSON files read/written with `fs`. Swap
  `readDB()` / `writeDB()` in `server.js` for a real database when
  you're ready to go beyond local demo use.
- Sessions and reset codes live in in-memory `Map`s in `server.js`.
  Restarting the server logs everyone out. For production, back these
  with Redis or a database table instead.
- Passwords are hashed with `scrypt` (Node's built-in `crypto`).


### Windows note
The development launcher starts the Node.js backend and invokes the Vite binary directly from `node_modules/.bin` to avoid Windows `npm exec` spawn EINVAL issues. Run `npm install` once, then `npm run dev`.
